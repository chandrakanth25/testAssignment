import { Component } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})

export class AppComponent {
  title = 'TestAssignment';
  
  getData;
  error

API_KEY = "e7IuSnhvPeZJmV1iuetzGORZq5H0-G4e-5-vY-i4wnTxUmASSt2ZOCHtTdC1ea50RHkck99CfSdDsN1KzrXwnuo2bRINoMLt6o9S1BLSd-_GOwB2g5LWU8BtQaORYHYx"
  constructor(private http: HttpClient,) {
    let headers = new HttpHeaders() 
    headers = headers.set('Content-Type', 'application/json');
    headers = headers.set('Access-Control-Allow-Origin','*');
    headers = headers.append("Authorization", "Bearer " + 'e7IuSnhvPeZJmV1iuetzGORZq5H0-G4e-5-vY-i4wnTxUmASSt2ZOCHtTdC1ea50RHkck99CfSdDsN1KzrXwnuo2bRINoMLt6o9S1BLSd-_GOwB2g5LWU8BtQaORYHYx'); 
    this.http.get<any>('https://api.yelp.com/v3/businesses/search?location=alpharetta&term=icecream', { headers })
        .subscribe(
          res => {
            this.getData = res;
            console.log('Result:', res)
          },
          err => {
            console.log('Error', err);
            this.error = err;
          },
        );
  }
}
